package com.scottdavidson.cards.util;

public interface Game {

}
